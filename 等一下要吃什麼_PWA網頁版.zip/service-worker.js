self.addEventListener('fetch', function (event) {
  // 使用預設網路 fetch，不做離線快取
});
